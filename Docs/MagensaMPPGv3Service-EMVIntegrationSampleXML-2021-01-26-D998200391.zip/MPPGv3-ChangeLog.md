# CHANGELOG FOR MPPGv3 XML/SOAP EXAMPLE MESSAGES FOR USE WITH MPPG EMV INTEGRATION GUIDE

## 2021-01-26  Chuck Maggs <chuck.maggs@magtek.com>
* ALL PROCESSORS:
  - Updated <EMVSREDData>, <EncryptionType>, and <NumberOfPaddedBytes> XML properties to replace hardcoded values with parameters from reader data
* CHASE:
  - Added information about partial authorization
* FIRST DATA:
  - Consolidated CAPTURE, VOID, and REFUND into one example sinde the same data is used for all three transactions
* HEARTLAND:
  - Fixed misnamed processor names in examples
* TSYS:
  - Updated amount specification for TSYS to be dollars and cents only, as utilizing cents-only amounts can cause issues
  - Added information about tip adjust
* WORLDPAY:
  - Removed information about merchant soft descriptors, as WorldPay no longer supports them as of January 2021

## 2020-11-03  Chuck Maggs <chuck.maggs@magtek.com>
* Modified information in the data sections of ProcessEMVSRED / ProcessData calls to show values based on ARQC data as well as use of the encrypted data primitive (EMV tag DFDF59)
* Relabeled all existing MPPGv3 messages with filenames that identify them as MPPGv3 examples
* Added example mexxages for EPX (for MPPGv4 only)

## 2020-05-20  Chuck Maggs <chuck.maggs@magtek.com>

* Added missing <KeyValuePairOfStringstring> tags in <TransactionInputDetails> group for First Data and WorldPay SALE/AUTHORIZE request messages
* Separated out the CAPTURE request example from the VOID and REFUND request example, as CAPTURE can optionally include tip information

## 2020-04-02  Chuck Maggs <chuck.maggs@magtek.com>

* Added XML/SOAP example messages for Heartland

## 2020-03-31  Chuck Maggs <chuck.maggs@magtek.com>

* Updated Chase REFUND examples to indicate that REFUND for retail can use ProcessToken or ProcessReferenceID, but REFUND for restaurant must use ProcessToken
* Corrected the listing of key/value pairs in the Elavon SALE example
* Updated the TSYS CAPTURE/VOID/REFUND example to include key/value pairs for handling tips

## 2019-11-07  Chuck Maggs <chuck.maggs@magtek.com>

* First releasse of XML/SOAP example messages for MPPG EMV integration guide
