# CHANGELOG FOR XML/SOAP EXAMPLE MESSAGES FOR USE WITH MPPG EMV INTEGRATION GUIDE

## 2020-05-20  Chuck Maggs <chuck.maggs@magtek.com>

* Added missing <KeyValuePairOfStringstring> tags in <TransactionInputDetails> group for First Data and WorldPay SALE/AUTHORIZE request messages
* Separated out the CAPTURE request example from the VOID and REFUND request example, as CAPTURE can optionally include tip information

## 2020-04-02  Chuck Maggs <chuck.maggs@magtek.com>

* Added XML/SOAP example messages for Heartland

## 2020-03-31  Chuck Maggs <chuck.maggs@magtek.com>

* Updated Chase REFUND examples to indicate that REFUND for retail can use ProcessToken or ProcessReferenceID, but REFUND for restaurant must use ProcessToken
* Corrected the listing of key/value pairs in the Elavon SALE example
* Updated the TSYS CAPTURE/VOID/REFUND example to include key/value pairs for handling tips

## 2019-11-07  Chuck Maggs <chuck.maggs@magtek.com>

* First releasse of XML/SOAP example messages for MPPG EMV integration guide
